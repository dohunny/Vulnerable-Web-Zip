http://service.alice-mallory.com:40019/

Special Character is in FLAG...!
---
Author: 9ucc1